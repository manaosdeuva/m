
public enum Estado {
	ingresada,aceptada,rechazada;
	Estado(){
		
	}
}
