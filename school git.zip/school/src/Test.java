import java.util.LinkedList;

public class Test {

	public static void main(String[] args) {
		pija();
	}

	protected static void pija() {
		Estado aceptada = Estado.aceptada;
		Estado ingresada = Estado.ingresada;
		Estado rechazada = Estado.rechazada;
		int id = 0;

		Carrera[] ca = new Carrera[15];
		String[] nom = { "analista", "biotecnologia", "productor musical",
				"dise�o digital", "dise�o industrial", "videojuegos",
				"programador", "testing", "base de datos", "dise�o web",
				"dise�o grafico", "animaci�n", "computaci�n cientifica",
				"radiologia", "hardware" };
		Materia[] materias = { new Materia("organizacion empresarial", 2),
				new Materia("introduccion a la informatica", 2),
				new Materia("fundamentos de programacion", 6),
				new Materia("taller de herramientas de programacion", 6),
				new Materia("matematica", 4), new Materia("ingles tecnico", 2),
				new Materia("taller de creatividad e innovacion", 2),
				new Materia("sistemas administrativos", 2),
				new Materia("arquitectura y sistemas operativos", 2),
				new Materia("programacion1", 6),
				new Materia("taller de programacion1", 6),
				new Materia("programacion en nuevas tecnologias1", 6),
				new Materia("base de datos1", 2),
				new Materia("analisis y metodologia de sistemas", 4),
				new Materia("base de datos2", 2),
				new Materia("programacion2", 6),
				new Materia("taller de programacion2", 6),
				new Materia("programacion en nuevas tecnologias2", 6),
				new Materia("programacion3", 6),
				new Materia("taller de programacion3", 6),
				new Materia("proyecto final", 6),
				new Materia("seguridad e integridad de sistemas", 2),
				new Materia("calidad de software", 2),
				new Materia("estudios judaicos", 2) };
		System.out.println(nom.length);
		for (int i = 0; i < ca.length; i++) {
			ca[i] = new Carrera(i, nom[i]);
		}
		Alumno a = new Regular(0, "eze", 0);
		Becado b = new Becado(0, null, 0, 0, (char) 0);
		Carrera c = new Carrera(0, null);
		Curso d = new Curso(null, 0, null, 0);
		Escuela e = new Escuela();
		e.setCarreras(ca);
		/*
		 * for (Carrera carrera : ca) { System.out.println(carrera); }
		 */
		Curso[] cursos = { new Curso("1", 1, "progra", 1),
				new Curso("2", 2, "taller", 2), new Curso("3", 3, "arqyso", 3),
				new Curso("4", 4, "baseda", 4), new Curso("5", 5, "sisadm", 5) };
		Alumno[] alumnos = { new Regular(0, "gabriel", 6),
				new Becado(1, "Andres", 7, 99, 'a') };
		for (Curso cu : cursos) {
			cu.add(alumnos[0]);
			cu.add(alumnos[1]);
			e.addCurso(cu);
		}
		e.addSolicitud(new Solicitud(1, 1, ingresada, "progra", new Regular(0,
				"gabriel", 6)));
		e.addSolicitud(new Solicitud(2, 2, ingresada, "taller", a));
		e.addSolicitud(new Solicitud(3, 3, ingresada, "arqyso", a));
		e.addSolicitud(new Solicitud(4, 4, ingresada, "baseda", a));
		e.addSolicitud(new Solicitud(5, 5, ingresada, "sisadm", a));
		for (Materia m : materias) {
			System.out.println(m);
		}
		// new Alumno(0,"Gabriel",6);
		// new Becado(1,"Andres",7,99,'a');
		// new Carrera(0,"analista");
		// new Curso("12e",14,"progra",0);
		// new Materia("progra","programacion",4);
		// new Solicitud(2,0,ingresada,"progra",alu);
		// legajo nombre promedio ALUMNO
		// legajo nombre promedio porcentaje tipo BECADO
		// id nombre CARRERA
		// id cupo materia carrera CURSO
		// id nombre horas MATERIA
		// id carrera state materia alu SOLICITUD

		// System.out.println("niggas" +
		// e.chequearSolicitud(e.getSolicitudes().peek()));
		// System.out.println("");

		// System.out.println(e.buscarCurso("2"));
		// e.eliminarCurso("1");

		// System.out.println(" ");
		LinkedList z = e.getCursos();
		// while (!z.isEmpty()) {
		// System.out.println(z.pop());}
		z = e.getSolicitudes();
		// System.out.println("");
		// while (!z.isEmpty()) {
		// System.out.println(((Solicitud) z.pop())); }

	}

}
