public class Materia {
	private String id, nombre;
	private int horasPorSemana;

	public Materia(String id, String nombre, int horasPorSemana) {
		setId(id);
		setNombre(nombre);
		setHorasPorSemana(horasPorSemana);
	}

	public Materia(String nombre, int horasPorSemana) {
		// setId(nombre.substring(nombre.length() - 4));
		setId(nombre.substring(0, 3) + nombre.substring(nombre.length() - 3));
		setNombre(nombre);
		setHorasPorSemana(horasPorSemana);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getHorasPorSemana() {
		return horasPorSemana;
	}

	public void setHorasPorSemana(int horasPorSemana) {
		this.horasPorSemana = horasPorSemana;
	}
}
